@extends('layouts.master', ['title' => $title, 'breadcrumbs' => $breadcrumbs])

@push('style')
<link href="{{ asset('/') }}plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
<style>
    #modal-member-detail .modal-dialog {
        max-width: 680px;
    }
    #modal-member-detail .modal-body {
        padding: 1rem 1.25rem;
    }
    #modal-member-detail #detail-image {
        max-height: 170px !important;
        width: auto;
    }
    #modal-member-detail .table th,
    #modal-member-detail .table td {
        padding-top: .22rem;
        padding-bottom: .22rem;
    }
    @media (max-width: 767.98px) {
        #modal-member-detail .modal-dialog {
            max-width: 92%;
            margin: 1rem auto;
        }
        #modal-member-detail #detail-image {
            max-height: 140px !important;
        }
    }
</style>
@endpush

@section('content')
<div class="panel panel-inverse">
    <div class="panel-heading">
        <h4 class="panel-title">{{ $title }}</h4>
    </div>

    <div class="panel-body">
        <table id="datatable-renew" class="table table-striped table-bordered align-middle">
            <thead>
                <tr>
                    <th class="text-nowrap">No</th>
                    <th class="text-nowrap">Nama</th>
                    <th class="text-nowrap">No HP</th>
                    <th class="text-nowrap">Membership</th>
                    <th class="text-nowrap">Tgl. Lahir</th>
                    <th class="text-nowrap">Umur</th>
                    <th class="text-nowrap">Tgl. Register</th>
                    <th class="text-nowrap">Harga Paket</th>
                    <th class="text-nowrap">Tgl. Expired Lama</th>
                    <th class="text-nowrap">Status</th>
                    <th class="text-nowrap">Aksi</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modal-member-detail" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Member</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <img id="detail-image" src="{{ asset('img/user/user-10.jpg') }}" alt="Foto Member" class="img-fluid rounded border" style="max-height: 170px;">
                    </div>
                    <div class="col-md-8">
                        <table class="table table-sm table-borderless mb-3">
                            <tr><th style="width: 180px;">Nama</th><td id="detail-nama">-</td></tr>
                            <tr><th>No HP</th><td id="detail-nohp">-</td></tr>
                            <tr><th>Membership</th><td id="detail-membership">-</td></tr>
                            <tr><th>Tgl. Lahir</th><td id="detail-tgl-lahir">-</td></tr>
                            <tr><th>Umur</th><td id="detail-umur">-</td></tr>
                            <tr><th>Tgl. Register</th><td id="detail-register">-</td></tr>
                            <tr><th>Tgl. Expired</th><td id="detail-expired">-</td></tr>
                        </table>
                        <div id="detail-submember-wrap" style="display: none;">
                            <h6 class="mb-2">Sub Member</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-nowrap">Nama</th>
                                            <th class="text-nowrap">Tgl Lahir</th>
                                            <th class="text-nowrap">Umur</th>
                                        </tr>
                                    </thead>
                                    <tbody id="detail-submembers"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Form tersembunyi untuk mengirim request perpanjangan --}}
<form id="form-single-renew" method="POST" action="{{ route('members.process_bulk_renew') }}" style="display: none;">
    @csrf
    <input type="hidden" name="member_ids[]" id="member-id-input">
    <input type="hidden" name="metode" id="renew-metode-input">
    <input type="hidden" name="admin_fee_master_id" id="renew-admin-fee-master-id-input">
    <input type="hidden" name="renewal_mode" id="renewal-mode-input">
    <input type="hidden" name="no_kartu" id="renew-no-kartu-input">
    <input type="hidden" name="bank" id="renew-bank-input">
</form>

@endsection

@push('script')
<script src="{{ asset('/') }}plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="{{ asset('/') }}plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="{{ asset('/') }}plugins/sweetalert/dist/sweetalert.min.js"></script>

<script>
    function formatRupiahNumber(value) {
        return new Intl.NumberFormat('id-ID').format(Number(value || 0));
    }

    function parseIsoDate(value) {
        if (!value || typeof value !== 'string') {
            return null;
        }

        var parts = value.split('-');
        if (parts.length !== 3) {
            return null;
        }

        var year = parseInt(parts[0], 10);
        var month = parseInt(parts[1], 10);
        var day = parseInt(parts[2], 10);
        if (isNaN(year) || isNaN(month) || isNaN(day)) {
            return null;
        }

        return new Date(year, month - 1, day);
    }

    function cloneDate(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }

    function formatDisplayDate(date) {
        if (!(date instanceof Date) || isNaN(date.getTime())) {
            return '-';
        }

        var day = String(date.getDate()).padStart(2, '0');
        var month = String(date.getMonth() + 1).padStart(2, '0');
        var year = date.getFullYear();
        return day + '/' + month + '/' + year;
    }

    function formatIsoDateText(value) {
        return formatDisplayDate(parseIsoDate(value));
    }

    function calculateAgeBreakdown(dateString) {
        if (!dateString) {
            return '-';
        }

        var birth = new Date(dateString + 'T00:00:00');
        if (isNaN(birth.getTime())) {
            return '-';
        }

        var today = new Date();
        var years = today.getFullYear() - birth.getFullYear();
        var months = today.getMonth() - birth.getMonth();
        var days = today.getDate() - birth.getDate();

        if (days < 0) {
            months -= 1;
            var previousMonth = new Date(today.getFullYear(), today.getMonth(), 0);
            days += previousMonth.getDate();
        }

        if (months < 0) {
            years -= 1;
            months += 12;
        }

        return years + ' tahun ' + months + ' bulan ' + days + ' hari';
    }

    function addDays(date, days) {
        var result = cloneDate(date);
        result.setDate(result.getDate() + days);
        return result;
    }

    function expiryFromStart(date, duration) {
        var startDate = cloneDate(date);

        if (duration <= 0) {
            return startDate;
        }

        var monthsToAdd = resolveMonthCycleCount(duration);
        if (monthsToAdd !== null) {
            var originalDay = startDate.getDate();
            var targetMonthDate = new Date(startDate.getFullYear(), startDate.getMonth() + monthsToAdd + 1, 0);
            var targetDay = Math.min(originalDay, targetMonthDate.getDate());

            return new Date(targetMonthDate.getFullYear(), targetMonthDate.getMonth(), targetDay);
        }

        return addDays(startDate, duration);
    }

    function resolveMonthCycleCount(duration) {
        if (duration <= 0) {
            return null;
        }

        var monthlyDurations = [30, 31];
        for (var i = 0; i < monthlyDurations.length; i++) {
            if (duration % monthlyDurations[i] === 0) {
                return duration / monthlyDurations[i];
            }
        }

        return null;
    }

    function expiryAfterCycles(anchorStartDate, duration, cycleNumber) {
        cycleNumber = Math.max(parseInt(cycleNumber, 10) || 1, 1);

        if (duration <= 0) {
            return cloneDate(anchorStartDate);
        }

        if (resolveMonthCycleCount(duration) !== null) {
            return expiryFromStart(anchorStartDate, duration * cycleNumber);
        }

        return addDays(anchorStartDate, duration * cycleNumber);
    }

    function buildEstimatedRenewalPeriod(registerDateText, expiredDateText, duration, renewalMode) {
        var today = new Date();
        var todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        var parsedRegisterDate = parseIsoDate(registerDateText);
        var parsedExpiredDate = parseIsoDate(expiredDateText);

        if (renewalMode === 'renewal_baru') {
            return {
                startDate: todayDate,
                expiredAt: expiryFromStart(todayDate, duration)
            };
        }

        var anchorStartDate = parsedRegisterDate || todayDate;
        var referenceExpiredAt = parsedExpiredDate || anchorStartDate;
        var cycleNumber = 1;
        var nextExpiredAt = expiryAfterCycles(anchorStartDate, duration, cycleNumber);

        while (nextExpiredAt.getTime() <= referenceExpiredAt.getTime()) {
            cycleNumber += 1;
            nextExpiredAt = expiryAfterCycles(anchorStartDate, duration, cycleNumber);
        }

        var previousExpiredAt = cycleNumber > 1
            ? expiryAfterCycles(anchorStartDate, duration, cycleNumber - 1)
            : anchorStartDate;

        return {
            startDate: addDays(previousExpiredAt, 1),
            expiredAt: nextExpiredAt
        };
    }

    var table = $('#datatable-renew').DataTable({
        processing: true,
        serverSide: true,
        responsive: true,
        ajax: {
            url: "{{ route('members.get_renewable') }}",
        },
        deferRender: true,
        pagination: true,
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'nama', name: 'nama' },
            { data: 'no_hp', name: 'no_hp' },
            { data: 'membership.name', name: 'membership.name' },
            { data: 'tgl_lahir', name: 'tgl_lahir', render: function (data) { return formatIsoDateText(data); }, orderable: false, searchable: false },
            { data: 'tgl_lahir', name: 'tgl_lahir_age', render: function (data) { return calculateAgeBreakdown(data); }, orderable: false, searchable: false },
            { data: 'tgl_register', name: 'tgl_register' },
            { data: 'package_price', name: 'package_price' },
            { data: 'tgl_expired', name: 'tgl_expired' },
            { data: 'renewal_status', name: 'renewal_status', orderable: false, searchable: false },
            { data: 'action', name: 'action', orderable: false, searchable: false },
        ],
    });

    // --- Logika Perpanjangan Individual ---

    $('#datatable-renew').on('click', '.btn-renew-single', function(e) {
        e.preventDefault();
        var memberId = $(this).data('id');
        var memberName = $(this).data('name');
        var memberBasePriceRaw = parseInt($(this).attr('data-price-base-raw') || '0', 10) || 0;
        var memberPpnPriceRaw = parseInt($(this).attr('data-price-ppn-raw') || '0', 10) || 0;
        var memberRegisterDate = $(this).attr('data-register-date') || '';
        var memberExpiredDate = $(this).attr('data-expired-date') || '';
        var memberDurationDays = parseInt($(this).attr('data-duration-days') || '0', 10) || 0;
        var renewalMode = $(this).data('renewal-mode') || 'renewal';
        var isRenewalBaru = renewalMode === 'renewal_baru';
        var confirmTitle = isRenewalBaru ? "Konfirmasi Perpanjangan Baru" : "Konfirmasi Perpanjangan";
        var confirmButton = isRenewalBaru ? "Ya, Perpanjangan Baru!" : "Ya, Perpanjang!";
        var adminOptionsRaw = $(this).attr('data-admin-options') || '[]';
        var adminOptions = [];

        try {
            adminOptions = JSON.parse(adminOptionsRaw);
            if (!Array.isArray(adminOptions)) {
                adminOptions = [];
            }
        } catch (error) {
            adminOptions = [];
        }

        var paymentWrapper = document.createElement('div');
        paymentWrapper.style.display = 'grid';
        paymentWrapper.style.gap = '8px';

        var summaryBox = document.createElement('div');
        summaryBox.className = 'alert alert-info text-start mb-1';
        summaryBox.id = 'renew-price-summary';
        paymentWrapper.appendChild(summaryBox);

        var adminLabel = document.createElement('label');
        adminLabel.setAttribute('for', 'renew-admin-fee-swal');
        adminLabel.textContent = 'Jenis Admin';
        paymentWrapper.appendChild(adminLabel);

        var adminSelect = document.createElement('select');
        adminSelect.id = 'renew-admin-fee-swal';
        adminSelect.className = 'swal-content__input';
        paymentWrapper.appendChild(adminSelect);

        var placeholderOption = document.createElement('option');
        placeholderOption.value = '';
        placeholderOption.textContent = '-- Pilih Jenis Admin --';
        placeholderOption.setAttribute('data-fee', '0');
        adminSelect.appendChild(placeholderOption);

        adminOptions.forEach(function(item) {
            var option = document.createElement('option');
            option.value = item.id;
            option.textContent = (item.admin_type || '-') + ' (Rp ' + formatRupiahNumber(item.admin_fee || 0) + ')';
            option.setAttribute('data-fee', String(parseInt(item.admin_fee || 0, 10) || 0));
            adminSelect.appendChild(option);
        });

        var metodeLabel = document.createElement('label');
        metodeLabel.setAttribute('for', 'renew-metode-swal');
        metodeLabel.textContent = 'Metode Pembayaran';
        paymentWrapper.appendChild(metodeLabel);

        var metodeSelect = document.createElement('select');
        metodeSelect.id = 'renew-metode-swal';
        metodeSelect.className = 'swal-content__input';
        paymentWrapper.appendChild(metodeSelect);

        var noKartuInput = document.createElement('input');
        noKartuInput.type = 'text';
        noKartuInput.id = 'renew-no-kartu-swal';
        noKartuInput.className = 'swal-content__input renew-card-field';
        noKartuInput.placeholder = 'No Kartu / No Rekening';
        noKartuInput.style.display = 'none';
        paymentWrapper.appendChild(noKartuInput);

        var bankInput = document.createElement('input');
        bankInput.type = 'text';
        bankInput.id = 'renew-bank-swal';
        bankInput.className = 'swal-content__input renew-card-field';
        bankInput.placeholder = 'Bank';
        bankInput.style.display = 'none';
        paymentWrapper.appendChild(bankInput);

        var paymentMethodOptions = @json(\App\Support\PaymentMethod::options());

        Object.entries(paymentMethodOptions).forEach(function(item) {
            var option = document.createElement('option');
            option.value = item[0];
            option.textContent = item[1];
            metodeSelect.appendChild(option);
        });

        function getSelectedAdminFee() {
            var selectedOption = adminSelect.options[adminSelect.selectedIndex];
            if (!selectedOption) {
                return 0;
            }
            return parseInt(selectedOption.getAttribute('data-fee') || '0', 10) || 0;
        }

        function renderRenewSummary() {
            var adminFee = getSelectedAdminFee();
            var total = memberBasePriceRaw + memberPpnPriceRaw + adminFee;
            var estimatedPeriod = buildEstimatedRenewalPeriod(
                memberRegisterDate,
                memberExpiredDate,
                memberDurationDays,
                renewalMode
            );
            summaryBox.innerHTML = ''
                + 'Harga Dasar: <strong>Rp ' + formatRupiahNumber(memberBasePriceRaw) + '</strong><br>'
                + 'PBJT: <strong>Rp ' + formatRupiahNumber(memberPpnPriceRaw) + '</strong><br>'
                + 'Biaya Admin: <strong>Rp ' + formatRupiahNumber(adminFee) + '</strong><br>'
                + 'Total: <strong>Rp ' + formatRupiahNumber(total) + '</strong><br>'
                + 'Periode Aktif Baru: <strong>' + formatDisplayDate(estimatedPeriod.startDate) + '</strong><br>'
                + 'Aktif Sampai: <strong>' + formatDisplayDate(estimatedPeriod.expiredAt) + '</strong>';
        }

        function toggleRenewCardFields() {
            var isCardMethod = metodeSelect.value === 'debit' || metodeSelect.value === 'kredit';
            var displayMode = isCardMethod ? 'block' : 'none';

            noKartuInput.style.display = displayMode;
            bankInput.style.display = displayMode;

            if (!isCardMethod) {
                noKartuInput.value = '';
                bankInput.value = '';
            }
        }

        metodeSelect.addEventListener('change', toggleRenewCardFields);
        adminSelect.addEventListener('change', renderRenewSummary);
        toggleRenewCardFields();
        renderRenewSummary();

        swal({
            title: confirmTitle,
            text: "Anda yakin ingin memperpanjang keanggotaan " + memberName + " (beserta submember-nya)?",
            content: paymentWrapper,
            icon: "warning",
            buttons: ["Batal", confirmButton],
            dangerMode: true,
        })
        .then((willRenew) => {
            if (willRenew) {
                var selectedMetode = (metodeSelect.value || '').trim();
                var selectedAdminFeeMasterId = (adminSelect.value || '').trim();
                var isCardMethod = selectedMetode === 'debit' || selectedMetode === 'kredit';
                var noKartu = (noKartuInput.value || '').trim();
                var bank = (bankInput.value || '').trim();

                if (isCardMethod && (!noKartu || !bank)) {
                    swal("Data pembayaran belum lengkap", "Untuk metode debit/kredit, isi nomor kartu/rekening dan bank.", "warning");
                    return;
                }

                // Set ID member ke form tersembunyi
                $('#member-id-input').val(memberId);
                $('#renew-metode-input').val(selectedMetode);
                $('#renew-admin-fee-master-id-input').val(selectedAdminFeeMasterId);
                $('#renewal-mode-input').val(renewalMode);
                $('#renew-no-kartu-input').val(isCardMethod ? noKartu : '');
                $('#renew-bank-input').val(isCardMethod ? bank : '');

                // Submit form
                $('#form-single-renew').submit();
            }
        });
    });

    $('#datatable-renew').on('click', '.btn-member-detail', function(e) {
        e.preventDefault();
        var route = $(this).data('route');
        if (!route) return;

        $.get(route, function(response) {
            if (!response || response.status !== 'success' || !response.member) {
                return;
            }

            var member = response.member;
            var familyMembers = response.family_members || [];
            var subMembers = familyMembers.filter(function(item) {
                return (item.relation || '').toLowerCase().indexOf('sub') >= 0;
            });

            $('#detail-image').attr('src', member.image_profile || '{{ asset('img/user/user-10.jpg') }}');
            $('#detail-nama').text(member.nama || '-');
            $('#detail-nohp').text(member.no_hp || '-');
            $('#detail-membership').text((member.membership && member.membership.name) ? member.membership.name : '-');
            $('#detail-tgl-lahir').text(formatIsoDateText(member.tgl_lahir));
            $('#detail-umur').text(calculateAgeBreakdown(member.tgl_lahir));
            $('#detail-register').text(formatIsoDateText(member.tgl_register));
            $('#detail-expired').text(formatIsoDateText(member.tgl_expired));

            var $subList = $('#detail-submembers');
            var $subWrap = $('#detail-submember-wrap');
            $subList.empty();
            if (subMembers.length === 0) {
                $subWrap.hide();
            } else {
                $subWrap.show();
                subMembers.forEach(function(item) {
                    var ageText = calculateAgeBreakdown(item.tgl_lahir);
                    var birthText = formatIsoDateText(item.tgl_lahir);
                    $subList.append('<tr><td>' + (item.nama || '-') + '</td><td>' + birthText + '</td><td>' + ageText + '</td></tr>');
                });
            }

            $('#modal-member-detail').modal('show');
        });
    });

</script>
@endpush
